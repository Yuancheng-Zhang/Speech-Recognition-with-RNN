Please call Stella.
He is in the queue now.
How are you, sir?