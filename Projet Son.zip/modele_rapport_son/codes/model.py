# Define a recurrent neural network using CTCModel
# Define the network architecture
input_shape = x_train[0].shape
input_data = Input(name='input', shape=(input_shape))
masking = Masking(mask_value=padding_value)(input_data)
blstm = Bidirectional(LSTM(128, return_sequences=True, dropout=0.1))(masking)
blstm = Bidirectional(LSTM(128, return_sequences=True, dropout=0.1))(blstm)
blstm = Bidirectional(LSTM(128, return_sequences=True, dropout=0.1))(blstm)
dense = TimeDistributed(Dense(nb_labels+1, name="dense"))(blstm)
outrnn = Activation('softmax', name='softmax')(dense)
network = CTCModel([input_data], [outrnn])
    
network.compile(Adam(lr=0.0001, decay=1e-6))
network.summary()

history = network.fit(x=[x_train, y_train, x_train_len, y_train_len], y=np.zeros(nb_train), 
          batch_size=batch_size, epochs=nb_epochs, validation_split=0.1)

# Evaluation: loss, label error rate and sequence error rate are requested
eval = network.evaluate(x=[x_test, y_test, x_test_len, y_test_len], batch_size=
       batch_size, metrics=['loss', 'ler', 'ser'])
       
# Predict label sequences
pred = network.predict([x_test, x_test_len], batch_size=batch_size, max_value= 
       padding_value)
       
# Print the 10 first predictions
for i in range(10):  
   print("Prediction :", [j for j in pred[i] if j != -1], " -- Label : ", y_test[i]) 
