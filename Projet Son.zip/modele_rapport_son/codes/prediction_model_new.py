Decoded prediction text: "our has was very smo".
---- Decoded label text: "our house was very small".