Prediction : [23.  5.  0. 16. 18. 15.  4.  0.  1.  0.  2.  9. 20.
               5.  0.  9. 14.  0.  1. 20.  0. 14.  9.  7.  8. 20.]  
---- Label : [23.  5.  0. 16. 21. 20.  0. 15. 21. 18.  0.  2.  9.  
               4.  0.  9. 14.  0. 12.  1. 19. 20.  0. 14.  9.  7.  
               8. 20.  0.  0.  0.  0.  0.  0.  0.  0.  0.  0. ...] 
Decoded prediction text: "we prod a bite in at night".
---- Decoded label text: "we put our bid in last night".